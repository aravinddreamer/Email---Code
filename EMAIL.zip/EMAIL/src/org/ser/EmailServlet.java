package org.ser;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.model.EmailService;

/**
 * Servlet implementation class EmailServlet
 */
@WebServlet("/Email")
public class EmailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public EmailServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	      
	    String to=request.getParameter("to");  
	    String subject=request.getParameter("subject");  
	    String msg=request.getParameter("msg");  
	          
	    EmailService.send(to, subject, msg);  
	    out.print("message has been sent successfully");   
		System.out.println("HI EMAIL SERVLRT");
		response.getWriter().append("Served at: ").append(request.getContextPath());
		out.close();
	}
	}
